<?php
$user = "100026531012799";
$pass = "kangkang";
?>